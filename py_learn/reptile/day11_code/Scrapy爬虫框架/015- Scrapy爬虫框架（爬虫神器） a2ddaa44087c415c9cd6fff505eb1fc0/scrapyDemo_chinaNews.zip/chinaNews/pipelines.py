# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html


# useful for handling different item types with a single interface
from itemadapter import ItemAdapter
import openpyxl
import pymysql


class ChinanewsPipeline:
    def process_item(self, item, spider):
        return item


class ChinanewsToExcelPipeline:
    """
    将数据写入Excel文件
    """

    def open_spider(self, spider):
        self.workbook = openpyxl.Workbook()
        colName = ['newsType', 'newsTitle', 'newsHref', 'newsTime']
        for i in range(len(colName)):
            self.workbook['Sheet'].cell(1, i + 1).value = colName[i]

    def close_spider(self, spider):
        self.workbook.save('./data.xlsx')

    def process_item(self, item, spider):
        newsType = item['NewsType']
        newsTitle = item['NewsTitle']
        newsHref = item['NewsHref']
        newsTime = item['NewsTime']
        dataList = [newsType, newsTitle, newsHref, newsTime]
        rowIndex = self.workbook['Sheet'].max_row
        colIndex = 1
        for i in range(len(dataList)):
            self.workbook['Sheet'].cell(rowIndex + 1, colIndex).value = dataList[i]
            colIndex += 1

        return item


class ChinanewsToMySQLPipeline:
    # from scrapy.crawler import Crawler
    """
    将数据写入MySQL
    """

    @classmethod
    def from_crawler(cls, crawler):
        host = crawler.settings['DB_HOST']
        port = crawler.settings['DB_PORT']
        username = crawler.settings['DB_USER']
        password = crawler.settings['DB_PASS']
        database = crawler.settings['DB_NAME']
        return cls(host, port, username, password, database)

    def __init__(self, host, port, username, password, database):
        self.conn = pymysql.connect(host=host, port=port,
                                    user=username, password=password,
                                    database=database, charset='utf8mb4',
                                    autocommit=True)
        self.cursor = self.conn.cursor()

    def open_spider(self, spider):
        pass

    def close_spider(self, spider):
        self.conn.close()

    def process_item(self, item, spider):
        newsType = item['NewsType']
        newsTitle = item['NewsTitle']
        newsHref = item['NewsHref']
        newsTime = item['NewsTime']
        self.cursor.execute(
            'insert into `tb_news` '
            '(`newsType`, `newsTitle`, `newsHref`, `newsTime`) '
            'values (%s, %s, %s, %s)',
            (newsType, newsTitle, newsHref, newsTime)
        )
        return item
