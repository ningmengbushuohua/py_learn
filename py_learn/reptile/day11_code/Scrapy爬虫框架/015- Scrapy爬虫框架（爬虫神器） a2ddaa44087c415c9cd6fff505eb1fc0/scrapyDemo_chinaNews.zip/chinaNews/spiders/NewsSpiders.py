import scrapy
import re

from chinaNews.items import ChinanewsItem


class NewsspidersSpider(scrapy.Spider):
    name = 'NewsSpiders'
    allowed_domains = ['www.chinanews.com']
    start_urls = ['http://www.chinanews.com/']

    def parse(self, response):
        href = response.css(
            'body > div:nth-child(9) > div.news-right > div.top-jsxw > div.jsxw-title.lmtitle > a::attr(href)'
        ).get()  # 结果为： /scroll-news/news1.html
        for page in range(1, 11):
            link = self.start_urls[0] + re.sub(r'\d', str(page), href[1:])
            # http://www.chinanews.com/scroll-news/news1.html
            # print(link)
            yield scrapy.Request(url=link, callback=self.NewsInfo)

    def NewsInfo(self, response):
        liList = response.css(
            'body > div.w1280.mt20 > div.content-left > div.content_list > ul > li'
        )
        for li in liList:
            newsItem = ChinanewsItem()
            if li.css('li::attr(class)').get() != 'nocontent':
                # 新闻类型
                newsItem['NewsType'] = li.css('li > div.dd_lm > a::text').get()
                # 新闻标题
                newsItem['NewsTitle'] = li.css('li > div.dd_bt > a::text').get()
                # 新闻链接
                href = li.css('li > div.dd_bt > a::attr(href)').get()
                newsItem['NewsHref'] = self.start_urls[0] + href[1:]
                # 新闻发布时间
                newsItem['NewsTime'] = li.css('li > div.dd_time::text').get()
                yield newsItem

    # def NewsInfo(self, response):
    #     liList = response.xpath('./body/div[@class="w1280 mt20"]/div[@class="content-left"]/div[2]//li')
    #     for li in liList:
    #         newsItem = ChinanewsItem()
    #         if li.xpath('./@class').get() != 'nocontent':
    #             # 新闻类型
    #             newsItem['NewsType'] = li.xpath('./div[1]/a/text()').get()
    #             # 新闻标题
    #             newsItem['NewsTitle'] = li.xpath('./div[2]/a/text()').get()
    #             # 新闻链接
    #             href = li.xpath('./div[2]/a/@href').get()
    #             newsItem['NewsHref'] = self.start_urls[0] + href[1:]
    #             # 新闻发布时间
    #             newsItem['NewsTime'] = li.xpath('./div[3]/text()').get()
    #             yield newsItem
