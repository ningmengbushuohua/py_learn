# selenium 4
import os
import random

from selenium import webdriver
from selenium.webdriver.chrome.service import Service as ChromeService
from webdriver_manager.chrome import ChromeDriverManager


class SeleniumSetting:
    driverPath = r'./chromeDriver'
    '文件夹已存在' if os.path.exists(driverPath) else os.mkdir(driverPath)
    with open('UserAgent.txt', 'r', encoding='utf-8') as file:
        UserAgentList = eval(file.read())
    s = ChromeService(ChromeDriverManager(path=driverPath).install())

    def create_chrome(self):
        Options = webdriver.ChromeOptions()
        Options.add_argument('--headless')
        Options.add_argument('blink-settings=imagesEnabled=false')
        Options.add_argument(f"--user-agent={random.choice(self.UserAgentList)}")
        browser = webdriver.Chrome(service=self.s, options=Options)
        return browser
